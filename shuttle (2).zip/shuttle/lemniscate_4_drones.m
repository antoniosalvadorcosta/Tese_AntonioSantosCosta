

drone_init_multp_simulations;

drone_simu_lemniscate;


show_simulations_plots= 1;

drone_show_data;



